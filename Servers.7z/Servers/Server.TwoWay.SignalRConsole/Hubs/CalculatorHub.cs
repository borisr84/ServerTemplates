﻿using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Server.TwoWay.SignalRConsole.Hubs
{
    public class CalculatorHub : Hub
    {
        //Push
        public async Task SendDateTimeAsync()
        {
            if (Clients == null)
                return;

            await Clients.All.SendAsync("CurrentTime", DateTime.Now);
        }

        //Pull
        public async Task<double> Add(double num1, double num2)
        {
            return await Task.FromResult(num1 + num2);
        }
    }
}
